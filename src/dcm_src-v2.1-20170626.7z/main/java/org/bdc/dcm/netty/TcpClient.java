package org.bdc.dcm.netty;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.net.InetSocketAddress;
import org.bdc.dcm.netty.channel.AbstractChannelInitializer;
import org.bdc.dcm.vo.Server;

public class TcpClient extends NettyBoot {
	
	private Bootstrap bootstrap;

	public TcpClient(Server server) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		super(server);
		init();
	}

	private void init() throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		setWorkerGroup(new NioEventLoopGroup());
		bootstrap = new Bootstrap();
		bootstrap.group(getWorkerGroup()).channel(NioSocketChannel.class)
					.option(ChannelOption.SO_KEEPALIVE, true);
		String classUri = "org.bdc.dcm.netty.channel.tcp.Tcp" + getServer().getDataType() + "ChannelInitializer";
		Class<?> classType = Class.forName(classUri);
		@SuppressWarnings("unchecked")
		AbstractChannelInitializer<SocketChannel> channelInitializer = (AbstractChannelInitializer<SocketChannel>) classType.newInstance();
		channelInitializer.setNettyBoot(this);
		bootstrap.handler(channelInitializer);
	}

	@Override
	public void shutdown() {
		super.shutdown();
	}

	@Override
	public void task() throws Exception {
		if (null != getServer().getClientPort() && 0 < getServer().getClientPort())
			bootstrap.bind(getServer().getClientPort());
		if (invalidHost()) throw new Exception("invalid host!");
		setChannelFuture(bootstrap.connect(getServer().getHost(),
				getServer().getServerPort()).sync());
		addChannel(getChannelFuture().channel(), new InetSocketAddress(
				getServer().getHost(), getServer().getServerPort()),
				getServer().getSelfMac());
		getChannelFuture().channel().closeFuture().sync();
	}

}
