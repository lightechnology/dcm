package org.bdc.dcm.netty.handler;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import io.netty.util.Attribute;
import io.netty.util.concurrent.GlobalEventExecutor;

import java.util.Iterator;
import org.bdc.dcm.conf.ComConf;
import org.bdc.dcm.netty.NettyBoot;
import org.bdc.dcm.vo.DataPack;
import org.bdc.dcm.vo.NettyChannel;
import org.bdc.dcm.vo.e.DataPackType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 主要处理解析好的数据是否可接收和转发，还有就时记录数据来源和接口关系，以保证下发数据能找到正确的接口
 */
public class DataHandler extends SimpleChannelInboundHandler<DataPack> {
	
	final static Logger logger = LoggerFactory.getLogger(DataHandler.class);
	
	public static ChannelGroup channelGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
	
	private NettyBoot nettyBoot;
	
	public DataHandler(NettyBoot nettyBoot) {
		this.nettyBoot = nettyBoot;
	}

	@Override
	public void channelActive(final ChannelHandlerContext ctx) throws Exception {
		super.channelActive(ctx);
		channelGroup.add(ctx.channel());
		if (logger.isInfoEnabled())
			logger.info("remoteAddress: {} connected", ctx.channel().remoteAddress());
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		super.channelInactive(ctx);
		channelGroup.remove(ctx.channel());
		if (logger.isInfoEnabled())
			logger.info("remoteAddress: {} disconnected", ctx.channel().remoteAddress());
	}

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, DataPack msg)
			throws Exception {
	    // 给Channel加属性，遍历所有channel里面的mac，如果当前mac在里面找到，删，加到当前channel里
        NettyChannel nChannel = null;
	    if (DataPackType.Info == msg.getDataPackType() && null != msg.getMac() && 0 < msg.getMac().length()) {
    	    Iterator<Channel> iter = channelGroup.iterator();
            while (iter.hasNext()) {
                Channel ch = iter.next();
                if (!ch.id().asShortText().equals(ctx.channel().id().asShortText())) {
                    nChannel = ch.attr(ComConf.NETTY_CHANNEL_KEY).get();  
                    if (null != nChannel) {
                        nChannel.removeMac(msg.getMac());
                    }
                }
            }
            Attribute<NettyChannel> attr = ctx.attr(ComConf.NETTY_CHANNEL_KEY);
            nChannel = attr.get();  
            if (null == nChannel) {
                NettyChannel newNChannel = new NettyChannel();
                newNChannel.addMac(msg.getMac());
                newNChannel.setSocketAddress(msg.getSocketAddress());
                nChannel = attr.setIfAbsent(newNChannel);
                if (null != nChannel && nChannel != newNChannel) {
                    nChannel.addMac(msg.getMac());
                }
            } else {
                nChannel.addMac(msg.getMac());
            }
        }
	    // 分发数据
	    boolean dptb = DataPackType.Cmd == msg.getDataPackType();
        Iterator<Channel> iter = channelGroup.iterator();
        while (iter.hasNext()) {
            Channel ch = iter.next();
            nChannel = ch.attr(ComConf.NETTY_CHANNEL_KEY).get();
            if (null != nChannel) {
                if (dptb && nChannel.getMacs().contains(msg.getToMac())
                        || !dptb && !ch.id().asShortText().equals(ctx.channel().id().asShortText())) {
                    if (ch.isWritable()) {
                        msg.setSocketAddress(nChannel.getSocketAddress());
                        ch.writeAndFlush(msg);
                    }
                }
            }
        }
	}

	public NettyBoot getNettyBoot() {
		return nettyBoot;
	}

	public void setNettyBoot(NettyBoot nettyBoot) {
		this.nettyBoot = nettyBoot;
	}

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt)
            throws Exception {
        super.userEventTriggered(ctx, evt);
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent event = (IdleStateEvent) evt;
            if (event.state().equals(IdleState.READER_IDLE)) {
                if (logger.isInfoEnabled())
                    logger.info("channel: {} - {} READER_IDLE", ctx.channel().localAddress(), ctx.channel().remoteAddress());
            } else if (event.state().equals(IdleState.WRITER_IDLE)) {
                if (logger.isInfoEnabled())
                    logger.info("channel: {} - {} WRITER_IDLE", ctx.channel().localAddress(), ctx.channel().remoteAddress());
            } else if (event.state().equals(IdleState.ALL_IDLE)) {
                if (logger.isInfoEnabled())
                    logger.info("channel: {} - {} ALL_IDLE", ctx.channel().localAddress(), ctx.channel().remoteAddress());
            }
            // 发送心跳
            ctx.writeAndFlush(buildHeartBeatMessage(ctx));
        }
    }
    
    private DataPack buildHeartBeatMessage(ChannelHandlerContext ctx) {
        DataPack dataPack = new DataPack();
        dataPack.setDataPackType(DataPackType.HeartBeat);
        dataPack.setSocketAddress(ctx.channel().remoteAddress());
        dataPack.setTimestamp(System.currentTimeMillis());
        return dataPack;
    }
	
}