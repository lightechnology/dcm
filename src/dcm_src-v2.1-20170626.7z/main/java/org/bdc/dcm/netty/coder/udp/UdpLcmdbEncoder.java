package org.bdc.dcm.netty.coder.udp;

import java.net.SocketAddress;
import java.util.List;

import org.bdc.dcm.data.coder.LcmdbEncoder;
import org.bdc.dcm.data.coder.udp.DataUdpEncoder;
import org.bdc.dcm.netty.NettyBoot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.netty.channel.socket.DatagramPacket;

public class UdpLcmdbEncoder extends UdpEncoder {
	
	final static Logger logger = LoggerFactory.getLogger(UdpLcmdbEncoder.class);
	
	public UdpLcmdbEncoder(SocketAddress remoteAddress, NettyBoot nettyBoot) {
		super(logger, nettyBoot, new DataUdpEncoder(new LcmdbEncoder()));
		setRemoteAddress(remoteAddress);
	}

	@Override
	public void write(DatagramPacket cast, List<Object> out) {
		// 按照配置是否要间隔发送，如果要，注意缓存任务，分out列队
		// TODO Auto-generated method stub
		out.add(cast);
	}

}
