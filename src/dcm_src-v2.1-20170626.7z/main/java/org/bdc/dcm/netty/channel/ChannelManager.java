package org.bdc.dcm.netty.channel;

import io.netty.channel.Channel;
import io.netty.channel.ChannelId;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;

import java.net.SocketAddress;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.bdc.dcm.vo.DataPack;
import org.bdc.dcm.vo.e.DataPackType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.util.tools.ComParam;
import com.util.tools.Public;

public class ChannelManager implements Runnable {
	
	public final static Logger logger = LoggerFactory.getLogger(ChannelManager.class);

	private Lock lock;
	private Condition condition;
	private ChannelGroup channelGroup;
	private Map<String, Object[]> marks;
	private Queue<DataPack> msgQueue;
	private Queue<Channel> channelQueue;
	private AtomicInteger deep;
	private AtomicLong maxInCost;
	private AtomicLong maxOutCost;
	
	private Thread thread;
	private Thread monitorThread;

	private static final ChannelManager channelManager = new ChannelManager();

	private ChannelManager() {
		this.lock = new ReentrantLock();
		this.condition = lock.newCondition();
		this.channelGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);
		this.marks = new ConcurrentHashMap<String, Object[]>();
		this.msgQueue = new ConcurrentLinkedQueue<DataPack>();
		this.channelQueue = new ConcurrentLinkedQueue<Channel>();
		this.deep = new AtomicInteger(0);
		this.maxInCost = new AtomicLong(0);
		this.maxOutCost = new AtomicLong(0);
		
		this.thread = new Thread(this);
		this.monitorThread = new Thread(new Monitor());
		this.monitorThread.setDaemon(true);
		this.thread.start();
		this.monitorThread.start();
	}

	public static ChannelManager getInstance() {
		return channelManager;
	}

	public Object[] getChannel(String mac) {
		SocketAddress socketAddress = null;
		Object[] vs = marks.get(mac);
		if (null != vs) {
			socketAddress = (SocketAddress) vs[0];
			ChannelId channelId = (ChannelId) vs[1];
			Channel channel = channelGroup.find(channelId);
			if (null != channel)
				return new Object[]{socketAddress, channel};
		}
		return null;
	}
	
	public boolean setChannel(String mac, SocketAddress socketAddress, Channel channel) {
		if (marks.containsKey(mac))
			return false;
		marks.put(mac, new Object[]{socketAddress, channel.id()});
		channelGroup.add(channel);
		return true;
	}
	
	public boolean delChannel(String mac) {
		if (!marks.containsKey(mac))
			return false;
		Object[] value = marks.get(mac);
		channelGroup.remove(value[1]);
		marks.remove(mac);
		return true;
	}
	
	public boolean delChannel(SocketAddress socketAddress, Channel channel) {
		boolean result = false;
		Object[] value = new Object[]{socketAddress, channel.id()};
		Iterator<Entry<String, Object[]>> ite = marks.entrySet().iterator();
		while (ite.hasNext()) {
			Entry<String, Object[]> entry = ite.next();
			Object[] vt = entry.getValue();
			if (value[0].equals(vt[0]) && value[1].equals(vt[1])) {
				channelGroup.remove(channel);
				ite.remove();
				result = true;
			}
		}
		return result;
	}
	
	public boolean contains(Channel channel) {
		return channelGroup.contains(channel);
	}
	
	public boolean contains(String mac) {
		return marks.containsKey(mac);
	}

	@Override
	public void run() {
		while (true) {
			while (msgQueue.isEmpty())
				try {
					lock.lock();
					condition.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				} finally {
					lock.unlock();
				}
			while (!msgQueue.isEmpty()) {
				DataPack msg = msgQueue.poll();
				Channel channel = channelQueue.poll();
				deep.getAndDecrement();
				if (null != msg) {
					long start = System.currentTimeMillis();
					// 这里命令数据避免回发到下命令的原来的channel，但是从map数据结构看，一个mac只能对应一个channel，那么这里管理的channel只存消息数据源的mac和channel
					if (DataPackType.Cmd == msg.getDataPackType()) {
						int result = messageSending(channel, msg, marks.get(msg.getToMac()));
						if (-1 == result) continue;
						if (1 == result) {
							marks.remove(msg.getToMac());
						}
					} else {
						Iterator<Entry<String, Object[]>> ite1 = marks.entrySet()
								.iterator();
						while (ite1.hasNext()) {
							Map.Entry<String, Object[]> entry = (Entry<String, Object[]>) ite1
									.next();
							if (null != entry) {
								int result = messageSending(channel, msg, entry.getValue());
								if (-1 == result) continue;
								if (1 == result) {
									ite1.remove();
							}
							}
						}
					}
					long end = System.currentTimeMillis();
					logger.info("message transmit--------------------------start: {}, end: {}, all cost: {}", start, end, end - start);
				}
			}
		}
	}
	
	public void messagePublish(Channel channel, DataPack msg) {
		channelQueue.offer(channel);
		msgQueue.offer(msg);
		deep.getAndIncrement();
		try {
			lock.lock();
			condition.signalAll();
		} finally {
			lock.unlock();
		}
	}
	
	// 这个模型下担心channel发送数据被并发处理了，是否会出现问题
	private int messageSending(Channel channel, DataPack msg, Object[] vs) {
		if (null == vs) return -1;
		SocketAddress socketAddress = (SocketAddress) vs[0];
		ChannelId channelId = (ChannelId) vs[1];
		Channel ch = channelGroup.find(channelId);
		if (null != ch && ch.isOpen()) {
			if (null != ch && !ch.equals(channel)) {
				msg.setSocketAddress(socketAddress);
				ch.writeAndFlush(msg);
				return 0;
			}
			return 2;
		}
		channelGroup.remove(ch);
		return 1;
	}

	public void setMaxInCost(Long cost) {
		long maxCost = maxInCost.get();
		while (maxCost < cost && !maxInCost.compareAndSet(maxCost, cost))
			maxCost = maxInCost.get();
	}
	
	public void setMaxOutCost(Long cost) {
		long maxCost = maxOutCost.get();
		while (maxCost < cost && !maxOutCost.compareAndSet(maxCost, cost))
			maxCost = maxOutCost.get();
	}

	class Monitor implements Runnable {
		
		final Logger logger = LoggerFactory.getLogger(this.getClass());

		@Override
		public void run() {
			while (true) {
				long iu = maxInCost.getAndSet(0);
				long ou = maxOutCost.getAndSet(0);
				if (logger.isWarnEnabled())
					logger.warn(
							"Data transmit Queue is deep: {}, indata time cost max:: {}, outdata time cost max: {}",
							deep.get(), iu, ou);
				else {
					StringBuilder sb = new StringBuilder(
							"Data transmit Queue is deep: ").append(deep.get())
							.append(", indata time cost max: ").append(iu)
							.append(", outdata time cost max: ").append(ou);
					Public.p(sb.toString());
				}
				Public.sleepWithOutInterrupted(ComParam.ONEMIN);
			}
		}
		
	}
	
}
