package org.bdc.dcm.vo.e;

public enum Datalevel {
	NORMAL, DRAFT, DELETED;
}
