package org.bdc.dcm.intf;

public interface DataLogStore {

}
