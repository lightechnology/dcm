package org.bdc.dcm.netty.coder.tcp;

import java.util.List;

import org.bdc.dcm.data.coder.LcmdbEncoder;
import org.bdc.dcm.data.coder.tcp.DataTcpEncoder;
import org.bdc.dcm.netty.NettyBoot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.netty.buffer.ByteBuf;

public class TcpLcmdbEncoder extends TcpEncoder {

	final static Logger logger = LoggerFactory.getLogger(TcpLcmdbEncoder.class);
	
	public TcpLcmdbEncoder(NettyBoot nettyBoot) {
		super(logger, nettyBoot, new DataTcpEncoder<ByteBuf>(new LcmdbEncoder()));
	}

	@Override
	public void write(ByteBuf cast, List<Object> out) {
		// 按照配置是否要间隔发送，如果要，注意缓存任务
		out.add(cast);
	}
	
}