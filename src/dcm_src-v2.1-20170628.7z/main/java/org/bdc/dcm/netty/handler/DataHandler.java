package org.bdc.dcm.netty.handler;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import org.bdc.dcm.netty.NettyBoot;
import org.bdc.dcm.netty.channel.ChannelManager;
import org.bdc.dcm.server.LoggerManager;
import org.bdc.dcm.vo.DataPack;
import org.bdc.dcm.vo.e.DataPackType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 主要处理解析好的数据是否可接收和转发，还有就时记录数据来源和接口关系，以保证下发数据能找到正确的接口
 */
public class DataHandler extends SimpleChannelInboundHandler<DataPack> {
	
	final static Logger logger = LoggerFactory.getLogger(DataHandler.class);
	
	private NettyBoot nettyBoot;
	private ChannelManager channelManager;
	
	public DataHandler(NettyBoot nettyBoot) {
		this.nettyBoot = nettyBoot;
        this.channelManager = ChannelManager.getInstance();
	}

	@Override
	public void channelActive(final ChannelHandlerContext ctx) throws Exception {
		super.channelActive(ctx);
		channelManager.setChannel(ctx.channel());
		if (logger.isInfoEnabled()) {
		    LoggerManager.getInstance().logInfo(logger, "remoteAddress: " + ctx.channel().remoteAddress() + " connected");
			//logger.info("remoteAddress: {} connected", ctx.channel().remoteAddress());
		}
	}

	@Override
	public void channelInactive(ChannelHandlerContext ctx) throws Exception {
		super.channelInactive(ctx);
        channelManager.rmvChannel(ctx.channel());
		if (logger.isInfoEnabled()) {
		    LoggerManager.getInstance().logInfo(logger, "remoteAddress: " + ctx.channel().remoteAddress() + " disconnected");
			//logger.info("remoteAddress: {} disconnected", ctx.channel().remoteAddress());
		}
	}

	@Override
	protected void messageReceived(ChannelHandlerContext ctx, DataPack msg)
			throws Exception {
        Long cur = System.currentTimeMillis();
        channelManager.setMaxInCost(cur - msg.getTimestamp());
        msg.setTimestamp(cur);
        channelManager.messagePublish(ctx, msg);
	}

	public NettyBoot getNettyBoot() {
		return nettyBoot;
	}

	public void setNettyBoot(NettyBoot nettyBoot) {
		this.nettyBoot = nettyBoot;
	}

    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt)
            throws Exception {
        super.userEventTriggered(ctx, evt);
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent event = (IdleStateEvent) evt;
            if (event.state().equals(IdleState.READER_IDLE)) {
                if (logger.isInfoEnabled()) {
                    StringBuilder sb = new StringBuilder("channel: ").append(ctx.channel().localAddress()).append(" - ").append(ctx.channel().remoteAddress()).append(" READER_IDLE");
                    LoggerManager.getInstance().logInfo(logger, sb.toString());
                    //logger.info("channel: {} - {} READER_IDLE", ctx.channel().localAddress(), ctx.channel().remoteAddress());
                }
            } else if (event.state().equals(IdleState.WRITER_IDLE)) {
                if (logger.isInfoEnabled()) {
                    StringBuilder sb = new StringBuilder("channel: ").append(ctx.channel().localAddress()).append(" - ").append(ctx.channel().remoteAddress()).append(" WRITER_IDLE");
                    LoggerManager.getInstance().logInfo(logger, sb.toString());
                    //logger.info("channel: {} - {} WRITER_IDLE", ctx.channel().localAddress(), ctx.channel().remoteAddress());
                }
            } else if (event.state().equals(IdleState.ALL_IDLE)) {
                if (logger.isInfoEnabled()) {
                    StringBuilder sb = new StringBuilder("channel: ").append(ctx.channel().localAddress()).append(" - ").append(ctx.channel().remoteAddress()).append(" ALL_IDLE");
                    LoggerManager.getInstance().logInfo(logger, sb.toString());
                    //logger.info("channel: {} - {} ALL_IDLE", ctx.channel().localAddress(), ctx.channel().remoteAddress());
                }
            }
            // 发送心跳
            ctx.writeAndFlush(buildHeartBeatMessage(ctx));
        }
    }
    
    private DataPack buildHeartBeatMessage(ChannelHandlerContext ctx) {
        DataPack dataPack = new DataPack();
        dataPack.setDataPackType(DataPackType.HeartBeat);
        dataPack.setSocketAddress(ctx.channel().remoteAddress());
        dataPack.setTimestamp(System.currentTimeMillis());
        return dataPack;
    }
	
}