package org.bdc.dcm.intf;

import java.util.List;

import org.bdc.dcm.vo.DataTab;

public interface DataTabConf {
	
	public List<DataTab> getDataTabConf(String name);
	
}
