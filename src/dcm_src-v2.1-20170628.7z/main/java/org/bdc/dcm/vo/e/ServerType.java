package org.bdc.dcm.vo.e;

public enum ServerType {
	TCP_CLIENT, TCP_SERVER, UDP_CONNECT, HTTP_CLIENT, HTTP_SERVER;
}
