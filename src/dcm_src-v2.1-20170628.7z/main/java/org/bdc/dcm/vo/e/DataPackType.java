package org.bdc.dcm.vo.e;

public enum DataPackType {
    HeartBeat, Info, Cmd;
}
