package org.bdc.dcm.intf;

public interface DataDrive {

}
