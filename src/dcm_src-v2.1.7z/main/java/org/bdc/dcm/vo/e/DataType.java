package org.bdc.dcm.vo.e;

public enum DataType {
	String, Klv, Lcmdb, Jmstr, Xarjsn, Jmjsn;
}
